package cloudcruiser;

public class ResponseClass {
	
}
