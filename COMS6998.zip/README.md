# COMS 6998 project

This repository contains the project developed by the group known as **Cloud Cruisers** for the course _COMS 6998 - Modern Serverless Cloud Apps_ (Fall 2016).

Known members of this fabulous team are (in no particular order):

- Gaurav Mishra ([gm2715@columbia.edu](mailto:gm2715@columbia.edu))
- Plaban Mohanty ([pm2878@columbia.edu](mailto:pm2878@columbia.edu))
- Jose Ruiz ([jr3660@columbia.edu](mailto:jr3660@columbia.edu))
- Sarang Karpate ([sjk2218@columbia.edu](mailto:sjk2218@columbia.edu))
- Xi Zhang ([zhang.xi@columbia.edu](mailto:zhang.xi@columbia.edu))
